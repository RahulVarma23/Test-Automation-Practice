package exceptionSession;

public class InsufficientFundException extends Exception {

	public InsufficientFundException(String str) {
		//super(str);
		//System.out.println("You don`t have enough balance");
	}

}
