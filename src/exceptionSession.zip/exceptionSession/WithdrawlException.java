package exceptionSession;

public class WithdrawlException extends Exception {

	public WithdrawlException(String string) {
		super(string);
		//System.out.println("Please maintain min bal");
		// TODO Auto-generated constructor stub
	}

}
