package exceptionSession;

public class exceptionsessiom {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  int s=12;
  int s1=6;
 System.out.println(s/s1);
	
	  /*try { 
		  System.out.println(s/s1); 
	  }
	  catch(java.lang.ArithmeticException ae) {
		  System.out.println("Anjuli");
		  System.out.println(ae);
	  }*/
	
	 
  
	}

}
