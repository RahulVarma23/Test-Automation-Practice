package exceptionSession;

public class InsufficientFUnd extends Exception{

	public InsufficientFUnd() {
		//super(string);
		System.out.println("Insufficient balance");
	}
}
