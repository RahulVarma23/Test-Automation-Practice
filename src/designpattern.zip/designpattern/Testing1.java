package designpattern;

public class Testing1 {

	public static void main(String[] args) {
		Singleton s1 =Singleton.getInstance();
		s1.display();
		s1.print();
	}
}
